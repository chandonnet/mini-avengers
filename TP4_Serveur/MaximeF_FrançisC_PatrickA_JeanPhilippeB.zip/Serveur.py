'''
Created on 29 nov. 2013

@author: user
'''
#!/usr/bin/python   
# -*- coding: iso-8859-1 -*-
 
#import mysocket
import select 
import socket 
import sys 
import threading 

from os import listdir
import os
from xml.dom.minidom import parse, parseString
 

class serveur:
    """
    Squelette du serveur
    """
 
    # Se donner un objet de la classe socket.
    un_socket = socket.socket()
 
    # Socket connexion au client.
    connexion = None
 
    MAX_RECV = 1024
 
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.backlog = 5;
        self.threads = []
        self.un_socket.bind((host, port))    
 
        # Passer en mode ecoute.
        self.un_socket.listen(5)  
 
    def open_socket(self):
        try: 
            self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
            self.server.bind((self.host,self.port)) 
            self.server.listen(5) 
        except socket.error, (e, message): 
            print "Could not open socket: " + message 
            sys.exit(1)
    
    def createClient(self,username):
        clientSocket = socket.socket()
        client = client(self,clientSocket,username)
        clientSocket.send("Serveur:Bonjour!")
        
    def bonjour(self):
        "Traitement de <bonjour />"
        dom = parseString("<bonjour >")
        return dom.toxml()
        
    def message(self,sender,msg):
        "Traitement de <message />"
        dom = parseString("<messageClient><sender>"+sender+"</sender><message>"+msg+"</message></messageClient>")
        return dom.toxml()
    
    def messageAdmin(self,msg):
        "Traitement de <messageAdmin />"
        dom = parseString("<messageAdmin>"+msg+"</messageAdmin>")
        return dom.toxml()
    
    def videoLink(self,link):
        "Traitement de <link />"
        dom = parseString("<link>"+link+"</link>")
        return dom.toxml()

##########################################
class client (threading.Thread):
    
    def __init__(self, socket):
        threading.Thread.__init__(self)
        self.socket = socket

        
    def run(self):
        running = True
        while running:
            print('yo')
            
            
        
##########################################
### Main ###
if __name__ == '__main__':
    serv = serveur('localhost', 12351)
    
    msgServer = ""
   
        
    # On attend un message du client.
    msgClient = serv.connexion.recv(serv.MAX_RECV)
 
    try:
        dom = parseString(msgClient)
    except:
        print "XML invalide!"
        serv.connexion.close()
        break
             
    while(True):
        # Traitement de <bonjour />
        
        for node in dom.getElementsByTagName('bonjour'): 
            if node.firstChild == None:
                singleMessage = True
                msgServeur = serv.bonjour()
                
        # Traitement de <message />
            
        for node in dom.getElementsByTagName('message'): 
            if node.firstChild == None:
                msgServeur = serv.bonjour()
        
        # Traitement de <skipVideo />
            
        for node in dom.getElementsByTagName('skipVideo'): 
            if node.firstChild == None:
                msgServeur = serv.bonjour()
        
        
        # Traitement de <messageAdmin />
            
        for node in dom.getElementsByTagName('messageAdmin'): 
            if node.firstChild == None:
                msgServeur = serv.bonjour()
                
        # Traitement de <videoLink />
            
        for node in dom.getElementsByTagName('videoLink'): 
            if node.firstChild == None:
                msgServeur = serv.bonjour()
        
      
    
#########################################

